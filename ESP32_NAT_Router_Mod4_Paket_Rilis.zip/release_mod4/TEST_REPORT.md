# Laporan Pengujian – ESP32 NAT Router 2.4.23-mod.4

Status: **PASSED** = lulus pada lingkungan yang disebutkan. **FAILED** = gagal. **NOT TESTED** = belum dijalankan.

Belum ada pengujian di ESP32 fisik. Semua hasil di bawah berasal dari build, tes host (gcc di PC), tes browser terhadap mock API, dan emulasi QEMU. Tidak ada hasil hardware yang diklaim berhasil.

## Ringkasan alat uji
| Uji | Lingkungan | Hasil |
|---|---|---|
| Build bersih IDF 5.5.4 | PC | 0 warning, 0 error |
| Build ulang dari ZIP | PC, folder lain | biner identik |
| `test_uplink_logic.c` (kode `main/uplink_logic.c` asli) | gcc host | 71/71 PASS |
| `test_client_ctl.c` (regresi mod.3) | gcc host | 26/26 PASS |
| `test_mod4.py` (JS dashboard asli di Chromium, mock API) | Playwright | 64/64 PASS |
| `test_dash.py` (regresi login/setting/reboot) | Playwright | 24/24 PASS |
| Boot QEMU | qemu-xtensa | sampai WiFi init (lihat Laporan Build) |

## Daftar uji sesuai prompt (bagian 11)
| No | Uji | Status | Keterangan |
|---|---|---|---|
| 1 | Build bersih ESP-IDF 5.5.4 | **PASSED** | `log/build_final_clean.log` |
| 2 | Error dan warning relevan diperbaiki | **PASSED** | 0 warning (satu variabel tak terpakai di build pertama sudah dihapus) |
| 3 | Scan OPEN dan secured | **NOT TESTED** (hardware) | Penyebab di kode sudah diperbaiki (filter dihapus). Mock + browser: OPEN, WEP, WPA2, WPA3, Enterprise, SSID sama/BSSID beda tampil terpisah – PASS |
| 4 | Koneksi WPA/WPA2 | **NOT TESTED** | Validasi password + klasifikasi "password salah" – PASS di host. Alur UI dengan password salah – PASS di mock |
| 5 | WPA3 | **NOT TESTED** | Tidak ada AP WPA3. Firmware memakai SAE PWE hunt-and-peck + H2E (`WPA3_SAE_PWE_BOTH`) |
| 6 | Hotspot HP | **NOT TESTED** | Tidak ada perangkat |
| 7 | Deteksi captive portal | **NOT TESTED** (hardware) | Logika keputusan (302, 200 isi salah, DNS privat, gagal total ≠ portal) – PASS di host. Banner + banner global – PASS di browser |
| 8 | Status internet (terhubung / tidak tersedia / belum pasti / portal) | **NOT TESTED** (hardware) | 13 kasus keputusan – PASS di host. Teks persis tampil – PASS di browser |
| 9 | Smart Roaming khusus JANNET OPEN | **NOT TESTED** (hardware) | Filter: JANNET OPEN ya; JANNET WPA2, OWE, "jannet", "JANNET_2", SSID lain – ditolak, PASS di host. Badge JANNET hanya di BSSID OPEN – PASS di browser |
| 10 | Manual tidak diambil alih Smart Roaming | **NOT TESTED** (hardware) | Status "Ditangguhkan (Manual aktif)" – PASS di browser. Di kode, hanya task `mod_svc` yang mengubah konfigurasi STA |
| 11 | Pergantian jaringan tanpa reboot | **NOT TESTED** | Di kode tidak ada `esp_restart()`/`esp_wifi_stop()` pada jalur switch (diperiksa dengan pencarian kode). Belum dibuktikan di hardware |
| 12 | Uptime dan AP lokal selama pergantian | **NOT TESTED** | Tidak bisa diuji tanpa ESP32 + AP uplink |
| 13 | NAT, DHCP, dashboard | **NOT TESTED** (hardware) | Kode NAT/DHCP Martin tidak diubah. Dashboard – PASS di browser (mock). Checksum pengalihan DNS (IP+UDP, kirim dan balasan) – PASS di host |
| 14 | RAM dan ukuran biner | **PASSED** (statis) / **NOT TESTED** (runtime) | App 1.428.784 B muat di slot 1.536 KB (sisa 144.080 B). DRAM statis 65.584 B. Free heap saat berjalan belum diukur |

## Keterbatasan yang diketahui
- Probe internet memakai HTTP biasa (port 80), tanpa TLS. Portal yang hanya mencegat HTTPS tidak terlihat sebagai portal. Router menampilkan "BELUM DAPAT DIPASTIKAN" atau "TIDAK TERSEDIA", bukan portal palsu.
- Pengalihan DNS lama hanya untuk DNS UDP. DNS lewat TCP/DoH di HP tidak dialihkan.
- Pergantian ke uplink dengan IP statis (setting Martin) dan uplink Enterprise belum diuji.
- Saat berpindah, koneksi TCP client yang sedang berjalan putus karena IP publik berganti. Ini tidak bisa dihindari. Client lokal tetap terhubung ke hotspot sejauh driver WiFi mempertahankannya, tetapi hal ini tidak dijamin.
- Hanya 2.4 GHz. ESP32 tidak mendukung 5 GHz.
