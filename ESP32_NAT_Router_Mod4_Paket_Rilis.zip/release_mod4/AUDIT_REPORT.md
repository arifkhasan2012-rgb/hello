# Laporan Audit – ESP32 NAT Router 2.4.23-mod.4

Dasar: source mod.3 terakhir (2.4.23-mod.3, merged SHA256 `b4bd499b…95bb2`), yang berasal dari repo `arifkhasan2012-rgb/esp32-nat-mood` commit `a89024ee4190c4271ff7ff5c53e0eb14e8f653e0`. Proyek tidak dibuat ulang dan source tidak diganti versi lain.

## 1. Penyebab scan hanya menampilkan jaringan OPEN
Masalahnya ada di firmware, bukan di tampilan dashboard.

| Lokasi (mod.3) | Masalah |
|---|---|
| `main/roam.c` `do_scan()` | `if (!r.ssid[0] \|\| (!open && !same)) continue;` membuang semua jaringan berpassword kecuali SSID uplink Martin sendiri sebelum disimpan ke tabel hasil. `esp_wifi_scan_get_ap_records()` sebenarnya sudah mengembalikan semua jaringan. |
| `main/roam.c` `roam_select()` | Menolak BSSID yang bukan OPEN atau bukan SSID uplink. |
| `main/roam.c` `sta_point_to()` | Mengosongkan password saat mengarahkan STA ke SSID lain, jadi jaringan berpassword tidak bisa dipakai. |
| `include/roam.h` | Struktur hasil hanya punya flag `open`, tanpa tipe keamanan. |
| `dash_api.c` / `dash.html` | Hanya menampilkan apa yang dikirim firmware, jadi bukan sumber masalah. |

## 2. Masalah tambahan yang ditemukan saat audit
- Setelah uplink berganti, client tetap memakai DNS dari lease DHCP lama (120 menit). Bila uplink utama tidak tersedia saat client mendapat lease, DNS-nya 192.168.4.1. Captive DNS Martin lalu membajak semua nama ke 192.168.4.1. Akibatnya internet client "mati" walaupun uplink baru sehat. Ini diperbaiki dengan `uplink_dns.c`.
- Driver WiFi memakai `WIFI_STORAGE_FLASH` (default IDF). Setiap `esp_wifi_set_config` STA akan menulis SSID/password ke NVS `nvs.net80211`. Ini bertentangan dengan syarat "password Manual tidak permanen". Sekarang diganti `WIFI_STORAGE_RAM`. Martin tidak membaca konfigurasi dari NVS driver (ia memakai kuncinya sendiri), jadi tidak ada fitur yang terpengaruh.
- Timer reconnect Martin dan watchdog reconnect bisa ikut memanggil `esp_wifi_connect()` atau `esp_restart()` di tengah pergantian jaringan. Sekarang keduanya ditahan selama hot switch dan saat pengguna menekan "Putuskan".
- Deteksi internet mod.3 hanya satu probe HTTP, dan "HTTP lain = portal". Ini terlalu agresif. Sekarang dua probe ditambah indikator DNS/TCP, dengan 4 status eksklusif.

## 3. Fungsi dan file yang diubah
| File | Jenis | Perubahan |
|---|---|---|
| `main/roam.c` | ditulis ulang | Uplink manager: scan semua keamanan, Manual sementara, Smart Roaming JANNET OPEN, cek internet, hot switch, state machine |
| `include/roam.h` | ditulis ulang | API dan struktur status baru |
| `main/uplink_logic.c`, `include/uplink_logic.h` | baru | Logika murni yang dites di host |
| `main/uplink_dns.c`, `include/uplink_dns.h` | baru | Pengalihan DNS lama → DNS uplink baru |
| `main/esp32_nat_router.c` | 4 sisipan kecil | `WIFI_STORAGE_RAM`, `sta_reconnect_cancel()`, penahan reconnect/watchdog, lewati enterprise saat JANNET aktif |
| `main/netif_hooks.c` | 2 panggilan | `updns_upload` / `updns_download` |
| `components/http_server/dash_api.c` | diubah | `/api/roam` → `/api/uplink`, objek `up` di `/api/status`, password dihapus dari memori |
| `components/http_server/www/dash.html` | diubah | Tab Uplink baru, banner portal global, status internet di Ringkasan |
| `main/CMakeLists.txt`, `CMakeLists.txt`, `sdkconfig.defaults` | kecil | File baru, versi 2.4.23-mod.4, reproducible build |
| `tools/…` | tes | Tes host + browser baru, mock server |

## 4. Yang dipertahankan
- NAT/NAPT Martin, DHCP server AP (custom_dhcps), DNS AP, portmap, ACL, VPN WireGuard, halaman klasik `/`, `/dash`, IP 192.168.4.1, AP SSID/password, tabel partisi, semua kunci NVS lama.
- Fitur mod.3: speed limiter, batas waktu client, Free Heap KB, suhu "Tidak tersedia", optimasi buffer WiFi, `WIFI_PS_NONE`.
- Tidak ada OTA baru. Tidak ada `esp_restart()` di jalur pergantian jaringan.

## 5. Yang berubah perilakunya (perlu diketahui)
- UI Uplink mod.3 (mode OFF/AUTO/MANUAL, "any open", kunci BSSID) diganti Smart Roaming JANNET ON/OFF + Manual Universal sesuai prompt. Ambang, histeresis dan jeda mod.3 dimigrasi otomatis. Smart Roaming selalu mulai OFF setelah upgrade, karena perilakunya berbeda dari AUTO mod.3 (hanya JANNET). Pengguna menyalakannya sendiri di tab Uplink.
- Bila Smart Roaming ON saat boot, router langsung mencari JANNET OPEN dan tidak memakai SSID uplink Martin. Bila Smart Roaming dinyalakan saat router sudah terhubung, koneksi yang ada dipertahankan sampai JANNET terlihat di scan.
