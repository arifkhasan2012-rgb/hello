# Modifikasi di atas firmware Martin (esp32_nat_router v2.4.23)

Basis: https://github.com/martin-ger/esp32_nat_router commit 08da293 (v2.4.23).
Semua perubahan di file asli ditandai komentar `[MOD]`. Tidak ada fitur asli yang dihapus.

## Tahap 1 – Fondasi (v2.4.23-mod.1)

### File baru
- `include/event_log.h`, `main/event_log.c` – log event ring buffer 48 entri di RAM.
- `include/sys_health.h`, `main/sys_health.c` – sampling tiap 10 s: RAM (bebas, internal, minimum, blok terbesar, fragmentasi), beban CPU per core (FreeRTOS run-time stats), suhu die (sensor lama ESP32, hanya ditampilkan kalau terbukti valid), alasan reset termasuk alasan restart software yang disimpan di RTC RAM, histori 60 sampel (10 menit).
- `components/http_server/dash_api.c`, `http_internal.h` – halaman `/dash` dan API JSON `/api/session|login|logout|password|status|health|log|reboot|settings`.
- `components/http_server/www/dash.html` – dashboard baru (bahasa Indonesia), di-gzip saat build oleh `www/gzip_page.py`.
- `tools/dash_test/` – server mock + tes Playwright untuk semua tombol dashboard.

### Perubahan di file asli
- `cmd_router.c`: hash password admin jadi PBKDF2-HMAC-SHA256 10.000 iterasi (`$p2$...`). Format lama Martin (`salt:hash`) dan plaintext tetap diterima, dan dimigrasi otomatis saat login berhasil.
- `http_server.c`: pembatas percobaan login per IP (5 gagal → blokir 60 s, naik dua kali lipat sampai 15 menit) untuk login klasik dan /dash; `max_uri_handlers` +10; registrasi API dashboard; wrapper sesi/CSRF; reboot halaman klasik mencatat alasan.
- `esp32_nat_router.c`: `sys_health_init()` setelah NVS; event log untuk uplink putus/tersambung, client masuk/keluar; restart factory-reset dan watchdog mencatat alasan.
- `main/CMakeLists.txt`, `components/http_server/CMakeLists.txt`: file baru dan embed dashboard.
- `sdkconfig.defaults`: `CONFIG_FREERTOS_GENERATE_RUN_TIME_STATS=y`, `CONFIG_ESP_TIMER_TASK_STACK_SIZE=4096`.
- `CMakeLists.txt`: versi `2.4.23-mod.1`.

### Dampak ukuran (dibanding build asli dengan toolchain yang sama)
- App: 1.389.216 B (asli 1.371.504 B), sisa slot OTA 12%.
- IRAM: +108 B (88,8% terpakai). DRAM statis: +5,7 KB.

### Keterbatasan yang diketahui
- Sesi login tetap satu sesi (desain Martin); login di /dash menimpa sesi halaman klasik dan sebaliknya.
- Setelah password dimigrasi ke PBKDF2, firmware asli Martin tidak bisa memverifikasinya.
- Kalau password admin belum dibuat, siapa pun yang tersambung ke AP bisa membuatnya (sama seperti perilaku asli).
- Sensor suhu ESP32 klasik tidak terdokumentasi; di banyak chip nilainya macet di 128 °F, dan dashboard akan menampilkan "Tidak tersedia".

## Tahap 2A – Monitoring (v2.4.23-mod.2a)

Cakupan: hanya monitoring. Tidak ada perubahan di konfigurasi WiFi, NAT, `sdkconfig`/`sdkconfig.defaults`, `netif_hooks.c`, logika STA, atau file inti Martin lainnya.

### File baru
- `include/heap_watch.h`, `main/heap_watch.c` – timer 1 detik (esp_timer) yang membaca heap bebas dan minimum sejak boot.
  - Event RAM rendah: `LOW_FREE` (heap bebas di bawah ambang, histeresis +8 KB) dan `DIP` (minimum baru di bawah ambang yang terjadi di antara dua tick). Log paling sering 1x per 10 detik.
  - Event terakhir disimpan di RTC_NOINIT dengan checksum FNV. Data ini bertahan setelah restart software/panic/watchdog/brownout, dan hilang saat listrik dicabut.
  - Callback alokasi gagal (`heap_caps_register_failed_alloc_callback`, IRAM, counter atomik). Permintaan PSRAM dihitung terpisah karena board ini tidak punya PSRAM.
  - Sesi uji RAM memakai monitor minimum lokal IDF (`heap_caps_monitor_local_minimum_free_size_start/stop`). Sesi hanya aktif atas perintah user, berhenti otomatis setelah 24 jam, dan ditolak kalau heap < 8 KB. Akses dilindungi mutex, dan timer melewati tick kalau mutex sedang dipakai.
  - Ambang disimpan di NVS `heap_low_kb` (8–100 KB, default 30).
- `tools/csv_logger/csv_logger.py`, `README.md` – logger CSV di HP/PC (Termux), memakai library standar saja.
- `tools/dash_test/test_stage2a.py` – tes Playwright untuk semua tombol Tahap 2A.

### Perubahan di file Tahap 1 (bukan file Martin)
- `main/sys_health.c`: perbaikan bug CPU pada wrap 2^32 µs (71,6 menit). Selisih dihitung unsigned, `s_prev_total != 0 && dt != 0`. `min_free_heap` diambil dari `heap_watch_boot_min()` supaya tetap benar selama sesi uji. `heap_watch_init()` dipanggil dari `sys_health_init()`.
- `components/http_server/dash_api.c`: objek `hw` di `/api/status`; `POST /api/heaptest` (start/stop); `GET /api/ramcheck` (hanya memeriksa, `freed` selalu 0); `heap_low_kb` di `/api/settings`.
- `components/http_server/http_internal.h`: `DASH_API_URI_COUNT` 12.
- `components/http_server/www/dash.html`: kartu Pemantauan RAM Rendah, Sesi Uji RAM, Periksa RAM (pengganti "Bersihkan RAM" sesuai persetujuan), dan Rekam CSV (di browser). CSS nilai `.kv` diubah dari `word-break:break-all` ke `overflow-wrap:break-word`, supaya kata tidak terpotong di tengah.
- `main/CMakeLists.txt`: tambah `heap_watch.c`.
- `CMakeLists.txt`: versi `2.4.23-mod.2a`.
- `tools/dash_test/mock_server.py`: endpoint baru untuk tes.

### Dampak ukuran (full clean build ESP-IDF 5.5.4, 0 warning)
- App: 0x155350 = 1.397.584 B (Tahap 1: 1.389.216 B, +8.368 B), sisa slot OTA 0x2acb0 (11%).
- IRAM: 116.471 B (88,86%, sisa 14.601 B), +88 B dibanding Tahap 1.
- DRAM statis: 49.504 B, +200 B. RTC slow noinit: 72 B.
- RAM runtime tambahan (perkiraan dari kode, belum diukur di hardware): esp_timer 1 detik tanpa task baru, mutex sekitar 100 B.

### Keterbatasan yang diketahui
- Tanpa sesi uji, lonjakan singkat (< 1 detik) yang tidak menembus minimum sejak boot tidak tertangkap. Sesi uji menutup celah ini.
- Selama sesi uji, perintah console `heap` Martin menampilkan minimum sesi, bukan minimum sejak boot. Dashboard tetap menampilkan keduanya dengan benar.
- Rekam CSV di browser bisa melambat kalau tab berada di latar belakang atau layar mati. Untuk rekaman panjang, pakai `csv_logger.py`.
- Satu sesi login (desain Martin): logger CSV dan browser saling menggantikan.

### Belum dikerjakan (tahap berikut)
2 Internet Sharing ON/OFF live, 3 speed limit per client, 4 smart roaming, 5 auto restart + anti boot-loop, 6 tab Clients/WiFi di /dash, 7 optimasi RAM.
Tahap 2B (speed limit), 2C (batas waktu), 2D (roaming): baru audit, belum ada izin implementasi.


---

## Mod 3 – Integrasi 7 fitur (versi 2.4.23-mod.3)

Dasar: Tahap 2A (2.4.23-mod.2a) dari repo `arifkhasan2012-rgb/esp32-nat-mood`, commit `a89024ee4190c4271ff7ff5c53e0eb14e8f653e0`. Semua perubahan diberi penanda `[MOD 3]`. Sistem NAT Martin, halaman `/`, `/dash`, IP 192.168.4.1, tabel partisi, dan konfigurasi NVS lama tidak diubah.

### File baru
- `include/client_ctl.h`, `main/client_ctl.c` – speed limiter + batas waktu per client.
- `include/roam.h`, `main/roam.c` – smart roaming uplink + task layanan `mod_svc`.
- `tools/host_test/` – tes host (gcc) yang meng-compile `main/client_ctl.c` apa adanya dengan stub IDF/lwIP.
- `tools/sim/tcp_policer_sim.py` – simulasi TCP-Reno untuk memilih ukuran burst.
- `tools/dash_test/test_mod3.py` – tes Playwright untuk tab Client/Uplink dan tampilan Free Heap. (`test_stage2a.py` dihapus karena kartu UI yang dites sudah dihapus sesuai Fitur 5.)

### Fitur 1 – Speed limiter upload/download per client
- Token bucket per MAC, terpisah untuk upload (hook input AP, setelah VPN killswitch) dan download (hook linkoutput AP, setelah ACL). Paket yang melebihi kuota dibuang (policer). TCP otomatis menurunkan laju, jadi throughput benar-benar terbatas, bukan cuma angka di dashboard.
- Kredit fixed-point (byte × 10^6), burst = 300 ms × laju (min 8000 B, maks 256 KB). Byte yang dihitung = panjang total IPv4 (header IP + payload).
- Dikecualikan: trafik ke subnet AP sendiri (192.168.4.x, termasuk dashboard/captive portal/DNS router), multicast/broadcast, dan non-IPv4 (ARP).
- Perubahan limit lewat `/api/client` langsung dipakai paket berikutnya (dibaca di jalur paket di bawah spinlock). Tidak perlu reboot, reconnect, atau restart NAT. Nilai 0 = unlimited, bucket langsung dilewati.
- Identitas = MAC, bukan IP, jadi limit tidak bocor saat client ganti IP atau reconnect. Bucket direset saat connect, sehingga client tidak membawa "tabungan" kredit.
- Dashboard menampilkan nilai dari struktur yang dipakai jalur paket (`up`/`down` di `/api/clients`) dan laju terukur rata-rata 2 detik.

### Fitur 2 – Batas waktu per client
- Batas dalam menit (0 = unlimited). Timer dihitung esp_timer 1 detik hanya selama client terhubung. Status: Unlimited / Berjalan / Dijeda / Habis.
- Saat habis: hanya akses internet yang diblok (upload dan download). Client tetap bisa membuka 192.168.4.1, `/dash`, dan captive portal. Client lain tidak terpengaruh. Admin bisa +30 menit, reset waktu, ubah batas, atau hapus profil.
- Persistensi: blob NVS `cctl_v1` (16 profil) + default `cc_dup`/`cc_ddn`/`cc_dtm`. NVS ditulis saat admin mengubah, saat waktu habis, saat client putus (minimal jeda 10 detik), dan tiap 300 detik bila ada perubahan. Tidak ada penulisan per detik.
- Salinan cepat di RTC_NOINIT dengan CRC dipulihkan setelah reset software/WDT/panic, jadi tidak ada detik yang hilang. Setelah power-on/brownout (RTC hilang) dipakai data NVS terakhir. Akibatnya maksimal 300 detik pemakaian terakhir tidak tercatat, dan selisih ini selalu menguntungkan client (sisa waktu tidak pernah berkurang).
- Semua sesi berstatus Dijeda setelah boot, sampai client terhubung lagi.
- Restart terencana (dashboard, halaman klasik, watchdog reconnect, factory reset) memanggil `cctl_persist_now()` sebelum `esp_restart()`.
- Default untuk client baru (limit + waktu) bisa diatur. Profil yang mengikuti default ikut berubah saat default diubah.
- Keterbatasan: HP dengan "MAC acak per jaringan" yang diganti dianggap client baru. Matikan MAC acak untuk SSID router ini agar batas tetap melekat.

### Fitur 3 – Smart roaming uplink WiFi
- Mode OFF (default, perilaku Martin), AUTO (sinyal terbaik), dan MANUAL (kunci BSSID). Konfigurasi di NVS `roam_cfg`.
- Selalu: scan semua channel + urut sinyal saat connect (`roam_prepare_sta_config`), jadi Martin langsung memilih AP terkuat dengan SSID uplink.
- Scan hanya karena pemicu, tidak terus-menerus: sinyal di bawah ambang (backoff 60→600 detik), scan lambat 900 detik bila rata-rata < −60 dBm, cek internet gagal 3×, uplink putus > 20/30 detik (lalu tiap 60 detik), kembali ke BSSID manual tiap 120 detik, atau tombol Scan.
- Hysteresis (default 8 dB) + jeda minimal antar-roam (default 120 detik) + rata-rata RSSI untuk mencegah ping-pong.
- Validasi internet: HTTP GET `connectivitycheck.gstatic.com/generate_204` (204 = OK, HTTP lain = captive portal). Setelah roam ada validasi 60 detik, dan bila gagal kembali ke AP sebelumnya. AP bermasalah diblok sementara 10 menit.
- MANUAL: bila BSSID pilihan hilang atau bermasalah, router pindah sementara ke AP terbaik, lalu kembali saat BSSID pilihan tersedia.
- Hasil scan hanya jaringan OPEN + SSID uplink sendiri (maks 20). AUTO berpindah ke SSID OPEN lain hanya bila opsi "any open" dicentang. SSID enterprise tidak pernah diubah.
- Hotspot AP ESP32 tetap hidup selama roaming (mode APSTA tidak diubah). Captive portal dan login tidak disentuh.
- Task statis `mod_svc` (stack 4096, prioritas 3) menjalankan layanan client dan roaming tiap 1 detik. Scan blocking menunggu event, bukan busy-loop.

### Fitur 4 – Optimasi RAM (tanpa PSRAM)
- `CONFIG_ESP_WIFI_DYNAMIC_RX/TX_BUFFER_NUM` 48 → 32 (default IDF). Ini batas atas buffer WiFi dari heap, jadi lonjakan heap terburuk saat banyak HP speedtest berkurang sekitar 16 × 1,6 KB per arah.
- Modul baru memakai alokasi statis: tabel client, stack + TCB task `mod_svc`, dan hasil scan. Tidak ada malloc per paket maupun per request. Hasil scan untuk JSON dashboard memakai stack handler.
- Dashboard: kartu dan JS RAM yang berat dihapus (lihat Fitur 5), sehingga request `/api/ramcheck` dan rekam CSV di browser tidak lagi dijalankan dari halaman.
- Hasil: DRAM statis naik 8.600 B (49.504 → 58.104 B) karena struktur statis di atas. Batas heap dinamis WiFi turun jauh lebih besar dari itu. Free heap runtime belum diukur di hardware.

### Fitur 5 – Monitoring RAM
- Ringkasan dan tab Sistem hanya menampilkan Free Heap (KB) + grafik free heap. Kartu Blok terbesar, Minimum, Fragmentasi, Pemantauan RAM Rendah, Sesi Uji RAM, Periksa RAM, dan Rekam CSV dihapus dari tampilan. API backend Tahap 2A tetap ada (dipakai `csv_logger.py`).

### Fitur 6 – Suhu chip
- Memakai implementasi Tahap 2A (`sys_health.c`): ESP32 klasik tidak punya driver temperature_sensor di IDF 5.5. Pembacaan `temprature_sens_read()` hanya ditampilkan bila nilainya masuk akal dan berubah-ubah. Bila tidak, statusnya "Tidak tersedia" atau "Menunggu". Tidak ada angka palsu. Sampling tiap 10 detik, dalam Celsius.

### Fitur 7 – Kinerja dan stabilitas
- `esp_wifi_set_ps(WIFI_PS_NONE)` setelah WiFi start: latency AP+STA lebih stabil.
- Jalur paket limiter di IRAM, hanya memakai spinlock pendek, tanpa alokasi dan tanpa log.
- Callback esp_timer singkat. Pekerjaan berat (NVS, scan, probe HTTP) ada di task `mod_svc` berprioritas rendah, sehingga tidak memblok httpd, lwIP, atau WiFi dan tidak memicu WDT.
- Roaming tidak menjalankan scan bila scan halaman `/scan` Martin sedang berjalan, dan tidak mengganti konfigurasi enterprise.
- Watchdog reconnect Martin (opsional) tetap ada. Bila diaktifkan, nilainya sebaiknya > 120 detik agar roaming sempat bekerja.

### API baru (login dashboard + header CSRF seperti API lain)
- `GET /api/clients`, `POST /api/client` {action: set|reset|add|delete|defaults}
- `GET /api/roam`, `POST /api/roam` {action: scan|now|select|config}

### File Tahap 2A yang diubah
`CMakeLists.txt` (versi), `main/CMakeLists.txt`, `main/esp32_nat_router.c`, `main/netif_hooks.c`, `main/sys_health.c`, `components/http_server/dash_api.c`, `components/http_server/http_internal.h` (URI 16), `components/http_server/www/dash.html`, `sdkconfig.defaults`, `tools/dash_test/mock_server.py`.

### Ukuran (full clean build ESP-IDF 5.5.4, 0 warning)
- App 1.414.432 B (0x159520), slot 0x180000 terpakai 89,9%.
- IRAM 117.563 B (89,69%, sisa 13.509 B). DRAM statis 58.104 B. RTC noinit 276 B.

## Mod 4 – Manual Universal WiFi + Smart Roaming JANNET + Captive Portal + Hot Switch (versi 2.4.23-mod.4)

Dasar: source mod.3 (bukan source baru). Semua perubahan diberi penanda `[MOD 4]`. NAT Martin, DHCP AP, halaman `/`, `/dash`, IP 192.168.4.1, tabel partisi dan kunci NVS lama tidak diubah. Tidak ada OTA baru.

### Akar masalah "scan hanya menampilkan jaringan OPEN"
- `main/roam.c` mod.3, fungsi `do_scan()`: filter `if (!r.ssid[0] || (!open && !same)) continue;` membuang setiap jaringan berpassword kecuali SSID uplink Martin sendiri. Jadi data memang tidak pernah sampai ke dashboard. Driver WiFi sendiri sudah mengembalikan semua jaringan.
- `roam_select()` / `sta_point_to()` juga menolak target berpassword dan mengosongkan password, sehingga walaupun tampil, jaringan berpassword tidak bisa dihubungkan.
- Perbaikan: scan menyimpan semua jaringan 2.4 GHz (maks 32, SSID tersembunyi dilewati), dengan tipe keamanan per BSSID. Filter "hanya JANNET OPEN" dipindah ke logika Smart Roaming saja (`upl_is_jannet`).

### File baru
- `include/uplink_logic.h`, `main/uplink_logic.c`: logika murni (tanpa IDF) yang dites di host: nama/dukungan keamanan, validasi password, klasifikasi reason disconnect, penghitung percobaan, filter JANNET, parser HTTP, keputusan status internet, checksum IP/UDP.
- `include/uplink_dns.h`, `main/uplink_dns.c`: pengalihan DNS lama setelah ganti jaringan (lihat Hot switch).
- `tools/host_test/test_uplink_logic.c`, `tools/dash_test/test_mod4.py` (menggantikan `test_mod3.py`, yang menguji UI Uplink lama yang sudah dihapus).

### Manual Universal WiFi
- Mendukung OPEN, OWE, WEP, WPA/WPA2/WPA3 Personal (termasuk mode transisi), hotspot Android/iPhone. Enterprise, WAPI dan DPP ditandai "tidak didukung". Hanya 2.4 GHz.
- Validasi password: WPA/WPA2 8-63 karakter atau 64 hex, WPA3 1-63, WEP 5/13 karakter atau 10/26 hex, hanya karakter ASCII yang dapat dicetak.
- Alur: DISCONNECTING → CONNECTING → AUTHENTICATING → OBTAINING_IP → INTERNET_CHECK → CONNECTED / CONNECTED_NO_INTERNET / CAPTIVE_PORTAL_DETECTED / FAILED.
- Pesan gagal: password salah (2× handshake gagal), autentikasi gagal (3×), DHCP gagal (20 detik tanpa IP), tidak ditemukan (3×), waktu habis (40 detik). Bila gagal, router kembali ke jaringan sebelumnya.
- Kredensial: `esp_wifi_set_storage(WIFI_STORAGE_RAM)` dipanggil setelah `esp_wifi_init`, jadi driver tidak menulis konfigurasi STA ke NVS. Firmware tidak menyimpan SSID/password Manual ke NVS. Salinan lokal dihapus (`wipe`) setelah dipakai. Password di body JSON dihapus dari memori cJSON. Setelah reboot, router memakai konfigurasi uplink Martin dari NVS (tidak berubah). Satu-satunya salinan yang tersisa selama sesi adalah yang ada di driver WiFi (RAM), karena dibutuhkan untuk reconnect otomatis. Salinan ini diganti saat Lepas Manual/ganti jaringan dan hilang saat restart atau mati.

### Captive portal / status internet
- Task `inet_chk` (stack statis 3584, prioritas 2) memeriksa setelah DHCP (3 detik setelah GOT_IP), lalu berkala: normal tiap `chk` detik (30-3600, default 300), portal tiap 20 detik, status lain tiap 30 detik.
- Bukti: HTTP `connectivitycheck.gstatic.com/generate_204` (harus 204), HTTP `captive.apple.com/hotspot-detect.html` (harus "Success"), DNS (IP privat = indikasi), TCP mentah 1.1.1.1:80.
- Keputusan (eksklusif): salah satu tanda tangan cocok → INTERNET TERHUBUNG. Dua probe dijawab dengan isi salah, atau satu dijawab dengan redirect/DNS privat → PERLU LOGIN CAPTIVE PORTAL. Semua gagal dua kali berturut-turut → INTERNET TIDAK TERSEDIA. Selain itu → STATUS INTERNET BELUM DAPAT DIPASTIKAN. Kegagalan total tidak pernah dianggap portal.
- Tidak ada bypass portal. Login dilakukan dari browser HP client.

### Smart Roaming JANNET
- Hanya SSID persis `JANNET` dengan keamanan OPEN. Semua BSSID JANNET OPEN adalah kandidat. JANNET berpassword, SSID lain, dan hotspot tidak pernah dipilih otomatis. Bila tidak ada JANNET, router tidak berpindah.
- Hysteresis (default 8 dB), jeda antar-roam (default 120 detik), rata-rata RSSI, scan karena pemicu saja (sinyal lemah dengan backoff 60→600 detik, scan lambat 900 detik), blacklist BSSID bermasalah 10 menit, validasi 90 detik setelah roam.
- Konfigurasi baru di NVS `roam_cfg2` (ON/OFF, ambang, hysteresis, jeda, interval cek). `roam_cfg` mod.3 dibaca sekali untuk migrasi ambang/histeresis/jeda. Smart Roaming mulai OFF. Tidak ada SSID/password yang disimpan.

### Pemisahan mode
- Hanya task `mod_svc` yang mengubah konfigurasi STA. Saat Manual aktif, Smart Roaming berstatus "Ditangguhkan". Permintaan connect kedua saat proses berjalan ditolak (`busy`). Scan tidak berjalan saat proses connect.

### Hot switch
- Tanpa `esp_restart()`, tanpa `esp_wifi_stop/deinit`. AP, NAT, DHCP AP, dan httpd tidak disentuh. Urutan: tahan reconnect Martin → `esp_wifi_disconnect` → tunggu → `esp_wifi_set_config` → `esp_wifi_connect`. Handler GOT_IP Martin mengaktifkan ulang NAPT/portmap/DNS AP seperti biasa.
- DNS client: client menyimpan DNS lama dari lease DHCP (120 menit). `uplink_dns.c` mengalihkan paket UDP port 53 dari client ke DNS lama (maks 4, berlaku 3 jam) ke DNS uplink baru, lalu memulihkan alamat sumber pada balasan (checksum inkremental RFC 1624). DNS lewat TCP tidak dialihkan.
- Client lokal bisa mengalami jeda internet beberapa detik saat berpindah. Koneksi TCP yang sedang berjalan akan putus karena IP publik berganti.

### Dashboard
- Tab Uplink ditulis ulang: status (state, mode, SSID, BSSID, channel, RSSI, keamanan, IP/gateway/DNS, status internet, waktu deteksi, hasil terakhir), tombol Cek Internet / Lepas Manual / Putuskan, kartu Smart Roaming JANNET, tabel scan dengan form password inline.
- Banner global "PERLU LOGIN CAPTIVE PORTAL" di semua tab. Ringkasan menampilkan status internet dan mode koneksi.
- API: `/api/roam` diganti `/api/uplink` (GET/POST: scan, connect, disconnect, release, check, roam_now, roam_cfg). `/api/status` mendapat objek `up`. Jumlah URI tetap 16.

### Build
- `CONFIG_APP_REPRODUCIBLE_BUILD=y` agar build ulang dari ZIP menghasilkan biner yang sama (tanggal/path tidak dimasukkan).
- DRAM statis 58.104 → 65.584 B (+7.480 B): task `inet_chk` (3.584 B stack + TCB), stack `mod_svc` 4096 → 4608, hasil scan 20 → 32 entri, buffer probe 640 B, tabel DNS. IRAM 117.563 → 117.583 B. App 1.414.432 → 1.428.784 B.
