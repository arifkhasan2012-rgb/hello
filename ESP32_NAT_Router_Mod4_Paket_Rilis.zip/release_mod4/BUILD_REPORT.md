# Laporan Build – ESP32 NAT Router 2.4.23-mod.4

## Toolchain
| Item | Versi |
|---|---|
| ESP-IDF | v5.5.4 |
| Compiler | xtensa-esp-elf-gcc 14.2.0 (esp-14.2.0_20260121) |
| esptool | 4.13.0 |
| Target | esp32 (klasik), 240 MHz, tanpa PSRAM |
| Optimasi | -O2 (Performance); `uplink_logic.c` -Os, `uplink_dns.c` -O2 |
| Flash | DIO, 40 MHz, 4 MB |
| Partisi | `partitions_example.csv` (tidak diubah, tabel partisi identik dengan mod.3) |

## Perintah
```
idf.py fullclean
idf.py build
esptool.py --chip esp32 merge_bin -o ESP32_NAT_ROUTER_FINAL_MERGED.bin \
  --flash_mode dio --flash_freq 40m --flash_size 4MB \
  0x1000 build/bootloader/bootloader.bin \
  0x8000 build/partition_table/partition-table.bin \
  0xf000 build/ota_data_initial.bin \
  0x20000 build/esp32_nat_router.bin
```

## Hasil
- Full clean build: **berhasil, 0 warning, 0 error** (`log/build_final_clean.log`).
- Build ulang dari `source_esp32_nat_router_mod4_final.zip` (diekstrak ke `/tmp/rb`, path berbeda): **0 warning**. Semua biner **identik byte demi byte** (app, bootloader, partition table, otadata) dan SHA256 file gabungan sama. Ini karena `CONFIG_APP_REPRODUCIBLE_BUILD=y` (`log/build_ulang_dari_zip.log`).
- Perubahan sdkconfig dari mod.3: hanya `CONFIG_APP_REPRODUCIBLE_BUILD=y`, yang otomatis mematikan `APP/BOOTLOADER_COMPILE_TIME_DATE`. Karena itu `bootloader.bin` berbeda beberapa byte dari mod.3 (tanggal build), tetapi isi fungsinya sama.

## Ukuran
| Item | mod.3 | mod.4 | Selisih |
|---|---|---|---|
| App (`esp32_nat_router.bin`) | 1.414.432 B | 1.428.784 B | +14.352 B |
| Sisa slot ota_0 (1.536 KB) | 158.432 B | 144.080 B | |
| IRAM | 117.563 B | 117.583 B (89,7 %) | +20 B |
| DRAM statis (.data+.bss) | 58.104 B | 65.584 B (36,3 %) | +7.480 B |
| File gabungan | 1.545.504 B | 1.559.856 B (0x17CD30) | |

Kenaikan DRAM statis berasal dari task `inet_chk` (stack 3.584 B + TCB), stack `mod_svc` 4.096 → 4.608 B, tabel hasil scan 20 → 32 entri, buffer probe HTTP 640 B, dan tabel DNS. Semuanya statis, jadi tidak ada fragmentasi heap dan tidak ada alokasi per paket. Free heap runtime belum diukur di ESP32 fisik.

## Verifikasi file gabungan
| Offset | Segmen | Ukuran | Cocok dengan hasil build |
|---|---|---|---|
| 0x1000 | bootloader.bin | 22.736 B | ya |
| 0x8000 | partition-table.bin | 3.072 B | ya |
| 0xF000 | ota_data_initial.bin | 8.192 B | ya |
| 0x20000 | esp32_nat_router.bin | 1.428.784 B | ya |

- `esptool image_info`: 6 segmen, chip ESP32, 4MB/40m/DIO, checksum valid, validation hash valid, versi 2.4.23-mod.4.
- File berakhir di 0x17CD30, di dalam ota_0 (berakhir di 0x1A0000) dan jauh di bawah 4 MB.
- Area NVS 0x9000–0xEFFF di file gabungan berisi 0xFF, jadi flash di 0x0 menghapus setting (lihat panduan).

## Emulasi QEMU (bukan hardware)
`log/qemu_boot_emulasi.log`: bootloader → app 2.4.23-mod.4 → NVS, FATFS, ACL, DHCP server, inisialisasi WiFi. Lalu berhenti di `esp_phy_enable` karena QEMU tidak punya radio WiFi. Ini sama dengan mod.3. Crash setelah soft reset terjadi di `esp_timer_init` sebelum `app_main`. Ini artefak soft-reset QEMU yang juga muncul di mod.3. QEMU tidak bisa menguji WiFi, scan, roaming, atau captive portal.
