# Daftar File yang Berubah (mod.4 terhadap mod.3)

Patch lengkap: `mod4_vs_mod3.patch`.

| File | Status | Baris (+/−) |
|---|---|---|
| `main/roam.c` | diubah (ditulis ulang) | +997 / −379 |
| `include/roam.h` | diubah | +97 / −48 |
| `main/uplink_logic.c` | baru | +288 |
| `include/uplink_logic.h` | baru | +126 |
| `main/uplink_dns.c` | baru | +141 |
| `include/uplink_dns.h` | baru | +21 |
| `main/esp32_nat_router.c` (Martin) | diubah, sisipan `[MOD 4]` | +18 / −4 |
| `main/netif_hooks.c` | diubah | +7 |
| `main/CMakeLists.txt` | diubah | +4 / −2 |
| `CMakeLists.txt` | versi 2.4.23-mod.4 | +1 / −1 |
| `sdkconfig.defaults`, `sdkconfig` | `CONFIG_APP_REPRODUCIBLE_BUILD=y` | +1 |
| `components/http_server/dash_api.c` | diubah | +108 / −64 |
| `components/http_server/www/dash.html` | diubah | +132 / −47 |
| `MOD_CHANGES.md` | bagian Mod 4 | +49 |
| `tools/host_test/test_uplink_logic.c` | baru | +160 |
| `tools/dash_test/test_mod4.py` | baru (menggantikan `test_mod3.py`) | +167 |
| `tools/dash_test/test_mod3.py` | dihapus (menguji UI Uplink lama) | −113 |
| `tools/dash_test/mock_server.py` | diubah | +68 / −26 |

File lain (NAT, DHCP, ACL, VPN, halaman klasik, partisi, client_ctl, sys_health, dll.) tidak diubah.
