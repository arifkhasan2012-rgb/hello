# Panduan Flashing: ESP Flash OTG (Android + kabel USB OTG)

Firmware: ESP32 NAT Router 2.4.23-mod.4 (lanjutan mod.3)
Target: ESP32 klasik (WROOM-32U), flash 4 MB, tanpa PSRAM. Direct flash lewat kabel, tanpa OTA.

## Pilihan A – File gabungan (setting terhapus)
| Item | Nilai |
|---|---|
| File | `ESP32_NAT_ROUTER_FINAL_MERGED.bin` |
| Alamat | **0x0** |
| Ukuran | 1.559.856 byte (0x17CD30) |
| SHA256 | `cd03c4582c2026c59514da467eb2cd44df33f430924e324c81d55ffa3bf19e8c` |
| Chip / mode / frekuensi / ukuran | ESP32 / DIO / 40 MHz / 4 MB |
| Baud | 115200 (paling aman). 460800 boleh dicoba |

**Apakah konfigurasi lama terhapus? Ya.** File gabungan menimpa 0x0–0x17CD30, termasuk NVS (0x9000–0xEFFF) yang diisi 0xFF. SSID/password uplink, password AP, password admin dashboard, portmap, limit client, dan setelan roaming kembali ke default (AP `ESP32_NAT_Router`, 192.168.4.1).

## Pilihan B – Pertahankan setting (disarankan bila sudah memakai mod.3)
Flash dua file dari folder `terpisah/` saja. Jangan centang file lain.

| File | Alamat | Ukuran | SHA256 |
|---|---|---|---|
| `ota_data_initial.bin` | **0xF000** | 8.192 B | `7d2c7ac4888bfd75cd5f56e8d61f69595121183afc81556c876732fd3782c62f` |
| `esp32_nat_router.bin` | **0x20000** | 1.428.784 B | `20930873cadf6b47605e1089701867ec7d37079d281aeb36e78254c93ff45237` |

- Tabel partisi identik dengan mod.3/Tahap 2A, jadi tidak perlu ditulis ulang. Bootloader lama tetap kompatibel.
- NVS tidak disentuh, jadi semua setting Martin dan mod.3 tetap ada. Ambang/histeresis roaming mod.3 dipertahankan. Smart Roaming JANNET mulai dalam keadaan OFF, jadi uplink Martin tetap dipakai sampai Anda menyalakannya.
- `ota_data_initial.bin` memastikan boot dari slot `ota_0` (alamat 0x20000).

## Langkah di HP
1. Salin file ke HP. Cocokkan SHA256 bila aplikasi/file manager menyediakan cek hash.
2. Colokkan ESP32 lewat adaptor OTG dan kabel USB data. Izinkan akses USB.
3. Buka ESP Flash OTG, lalu pilih chip **ESP32** dan baud **115200**.
4. Pilihan A: satu file di **0x0**. Pilihan B: dua file di **0xF000** dan **0x20000**.
5. Bila ada opsi mode/frekuensi/ukuran, pilih **DIO / 40 MHz / 4 MB** atau "keep".
6. Jangan pilih "Erase all" kecuali memang ingin menghapus setting.
7. Tekan Flash. Bila "Failed to connect", tahan **BOOT**, tekan dan lepas **EN/RST**, lepas BOOT, lalu ulangi.
8. Setelah selesai, tekan EN/RST sekali.

## Setelah boot
1. Sambungkan HP ke hotspot router, lalu buka `http://192.168.4.1/` (halaman Martin) atau `http://192.168.4.1/dash`.
2. Tab **Uplink**:
   - **Scan WiFi** menampilkan semua jaringan 2.4 GHz. Tekan **Hubungkan**. Jaringan berpassword meminta password. Password hanya disimpan di RAM dan hilang saat restart.
   - **Lepas Manual** kembali ke uplink Martin / Smart Roaming. **Putuskan** memutus uplink (hotspot tetap hidup).
   - **Smart Roaming JANNET**: ON/OFF dan parameter. Hanya SSID `JANNET` OPEN.
3. Bila muncul **PERLU LOGIN CAPTIVE PORTAL**, buka situs `http://` apa saja (mis. `http://neverssl.com`) dari HP yang terhubung ke hotspot router, lalu login.
4. Pengaturan uplink permanen tetap dilakukan di halaman klasik Martin `/`.

## Bila bermasalah
- Boot loop atau AP tidak muncul: flash Pilihan A di 0x0. Bila tetap gagal, kembali ke file gabungan mod.3 dengan cara yang sama.
- Lupa password admin: tahan BOOT 5 detik saat firmware berjalan untuk factory reset (fitur Martin).
